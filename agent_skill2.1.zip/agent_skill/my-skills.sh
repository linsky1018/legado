#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# my-skills bootstrap
# Usage:
#   pack.sh              → 打包技能到 my-skills-YYYYMMDD-HH.tar.gz
#   pack.sh install      → 解压 + 初始化 Hermes + 合并旧记忆
# ============================================================

WORKSPACE="${HOME}/.openclaw/workspace"
SKILLS_DIR="${WORKSPACE}/skills"
HERMES_DIR="${HOME}/hermes-agent"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ---- 打包 ----
do_pack() {
    local tag
    tag="my-skills-$(date +%Y%m%d-%H)"
    local archive="${tag}.tar.gz"

    echo "==> 打包技能: download-file, self-learning, hermes-agent"
    echo "    包含: ~/hermes-agent/ 记忆文件"
    echo "    排除: tdx_market_cache.pkl, __pycache__, archive/"
    echo "    输出: ${archive}"

    # 先把技能和记忆文件组织到临时目录
    local tmpdir
    tmpdir=$(mktemp -d)
    trap "rm -rf '${tmpdir}'" EXIT

    # 复制技能
    cp -r "${SKILLS_DIR}/download-file" "${tmpdir}/"
    cp -r "${SKILLS_DIR}/self-learning" "${tmpdir}/"
    cp -r "${SKILLS_DIR}/hermes-agent" "${tmpdir}/"

    # 复制 hermes 记忆文件
    if [[ -d "${HERMES_DIR}" ]]; then
        mkdir -p "${tmpdir}/hermes-memory"
        for f in memory.md promotions.md reflections.md workspace-state.md; do
            [[ -f "${HERMES_DIR}/${f}" ]] && cp "${HERMES_DIR}/${f}" "${tmpdir}/hermes-memory/"
        done
    fi

    tar czf "${archive}" \
        -C "${tmpdir}" \
        --exclude='tdx_market_cache.pkl' \
        --exclude='__pycache__' \
        --exclude='*.pyc' \
        --exclude='archive' \
        download-file \
        self-learning \
        hermes-agent \
        hermes-memory

    rm -rf "${tmpdir}"

    echo "==> 完成: ${archive} ($(du -h "${archive}" | cut -f1))"
}

# ---- 安装 ----
do_install() {
    local archive="$1"

    if [[ ! -f "${archive}" ]]; then
        echo "错误: 找不到 ${archive}" >&2
        exit 1
    fi

    # 1. 解压技能
    echo "==> 解压 ${archive} 到 ${SKILLS_DIR}"
    mkdir -p "${SKILLS_DIR}"
    tar xzf "${archive}" -C "${SKILLS_DIR}"

    # 2. 备份旧的 hermes-agent 目录（如果存在）
    if [[ -d "${HERMES_DIR}" ]]; then
        local backup="${HERMES_DIR}.bak.$(date +%s)"
        echo "==> 检测到已有 ${HERMES_DIR}，备份到 ${backup}"
        cp -r "${HERMES_DIR}" "${backup}"
        local OLD_MEMORY="${backup}/memory.md"
    else
        local OLD_MEMORY=""
    fi

    # 3. 创建 hermes-agent 目录结构
    echo "==> 初始化 Hermes 目录结构"
    mkdir -p "${HERMES_DIR}/archive"
    for f in memory.md promotions.md reflections.md workspace-state.md; do
        [[ -f "${HERMES_DIR}/${f}" ]] || touch "${HERMES_DIR}/${f}"
    done

    # 4. 初始化 memory.md（如果为空）
    if [[ ! -s "${HERMES_DIR}/memory.md" ]]; then
        # 优先用打包里的 hermes-memory/memory.md
        if [[ -s "${SKILLS_DIR}/../hermes-memory/memory.md" ]]; then
            echo "==> 从打包中恢复 memory.md"
            cp "${SKILLS_DIR}/../hermes-memory/memory.md" "${HERMES_DIR}/memory.md"
        elif [[ -s "${SKILLS_DIR}/hermes-memory/memory.md" ]]; then
            echo "==> 从打包中恢复 memory.md"
            cp "${SKILLS_DIR}/hermes-memory/memory.md" "${HERMES_DIR}/memory.md"
        else
            echo "==> 从模板初始化 memory.md"
            cat > "${HERMES_DIR}/memory.md" << 'MEMEOF'
# Hermes Agent Memory

## Status
status: active
version: 1.0.0
last: $(date +%Y-%m-%d)
integration: active

## Workspace Snapshot
- AGENTS.md: patched with Hermes retrieval block
- SOUL.md: patched with Hermes pressure block
- HEARTBEAT.md: patched with Hermes maintenance tasks

## Active Rules

## Promotion Signals

## Notes
- Initialized from my-skills bootstrap

---
Updated: $(date +%Y-%m-%d)
MEMEOF
        fi
    fi

    # 4b. 恢复其他记忆文件
    local packed_mem_dir=""
    for d in "${SKILLS_DIR}/../hermes-memory" "${SKILLS_DIR}/hermes-memory" "${SKILLS_DIR}/hermes-memory"; do
        [[ -d "${d}" ]] && packed_mem_dir="${d}" && break
    done
    if [[ -n "${packed_mem_dir}" ]]; then
        for f in promotions.md reflections.md workspace-state.md; do
            if [[ -s "${packed_mem_dir}/${f}" && ! -s "${HERMES_DIR}/${f}" ]]; then
                echo "    恢复 ${f}"
                cp "${packed_mem_dir}/${f}" "${HERMES_DIR}/${f}"
            fi
        done
    fi

    # 5. 合并旧的 memory.md（从备份或打包中）
    local merge_source=""
    if [[ -n "${OLD_MEMORY}" && -s "${OLD_MEMORY}" ]]; then
        merge_source="${OLD_MEMORY}"
    elif [[ -n "${packed_mem_dir}" && -s "${packed_mem_dir}/memory.md" ]] && [[ -s "${HERMES_DIR}/memory.md" ]]; then
        # memory.md 已被恢复，跳过（不会重复）
        merge_source=""
    fi
    if [[ -n "${merge_source}" ]] && ! grep -q "Imported Memory" "${HERMES_DIR}/memory.md"; then
        echo "==> 合并旧 memory.md"
        echo "" >> "${HERMES_DIR}/memory.md"
        echo "## Imported Memory ($(date +%Y-%m-%d))" >> "${HERMES_DIR}/memory.md"
        echo "<!-- 以下内容从旧环境导入，已去重请手动检查 -->" >> "${HERMES_DIR}/memory.md"
        echo '```' >> "${HERMES_DIR}/memory.md"
        cat "${merge_source}" >> "${HERMES_DIR}/memory.md"
        echo '```' >> "${HERMES_DIR}/memory.md"
        echo "==> 旧记忆已追加到 memory.md 末尾，请手动检查并去重"
    fi

    # 6. Patch workspace 文件（非破坏性）
    patch_agents_md
    patch_soul_md
    patch_heartbeat_md

    echo ""
    echo "========================================"
    echo "  ✅ 初始化完成！"
    echo "  技能目录: ${SKILLS_DIR}/"
    echo "  Hermes:   ${HERMES_DIR}/"
    echo "========================================"
}

# ---- Patch AGENTS.md ----
patch_agents_md() {
    local file="${WORKSPACE}/AGENTS.md"
    [[ -f "${file}" ]] || return 0

    if grep -q "Hermes Retrieval" "${file}"; then
        echo "    AGENTS.md: 已有 Hermes 块，跳过"
        return 0
    fi

    echo "    AGENTS.md: 添加 Hermes 检索块"
    # 在 "Don't ask permission. Just do it." 之后插入
    sed -i '/Don.*ask permission.*Just do it\./a\
\
### Hermes Retrieval\
\
For non-trivial work only:\
- Read `~/hermes-agent/memory.md` if it exists.\
- Read at most one additional Hermes file if the task clearly needs it.\
- Skip Hermes retrieval for trivial replies, casual chat, and one-shot questions.' "${file}"

    # 在 Write It Down 段添加路由规则
    if ! grep -q "hermes-agent/reflections.md" "${file}"; then
        sed -i '/Text > Brain.*📝/i - Reusable execution lesson → write to `~/hermes-agent/reflections.md`\
- Stable repeated rule → distill to `~/hermes-agent/memory.md`\
- Candidate workflow after repeated success → log to `~/hermes-agent/promotions.md`\
- Keep Hermes files short and operational; do not duplicate daily-log history there' "${file}"
    fi
}

# ---- Patch SOUL.md ----
patch_soul_md() {
    local file="${WORKSPACE}/SOUL.md"
    [[ -f "${file}" ]] || return 0

    if grep -q "Hermes Pressure" "${file}"; then
        echo "    SOUL.md: 已有 Hermes 块，跳过"
        return 0
    fi

    echo "    SOUL.md: 添加 Hermes Pressure 块"
    cat >> "${file}" << 'SOULEOF'

## Hermes Pressure

Retrieve before non-trivial work.
Reflect after meaningful work.
Prefer one distilled lesson over noisy self-commentary.
SOULEOF
}

# ---- Patch HEARTBEAT.md ----
patch_heartbeat_md() {
    local file="${WORKSPACE}/HEARTBEAT.md"
    [[ -f "${file}" ]] || return 0

    if grep -q "Hermes Maintenance" "${file}"; then
        echo "    HEARTBEAT.md: 已有 Hermes 块，跳过"
        return 0
    fi

    echo "    HEARTBEAT.md: 添加 Hermes Maintenance 块"
    sed -i '1a\
\
## Hermes Maintenance\
\
- [ ] Review `~/hermes-agent/reflections.md` for lessons worth distilling\
- [ ] Review `~/hermes-agent/promotions.md` for patterns ready to become skills\
- [ ] Keep `~/hermes-agent/memory.md` short and current' "${file}"
}

# ---- Main ----
case "${1:-pack}" in
    pack)
        do_pack
        ;;
    install)
        if [[ $# -lt 2 ]]; then
            echo "用法: $0 install <archive.tar.gz>"
            echo "  或: $0 install  (自动找当前目录最新的 .tar.gz)"
            # 自动找最新包
            archive=$(ls -t "${SCRIPT_DIR}"/my-skills-*.tar.gz 2>/dev/null | head -1)
            if [[ -z "${archive}" ]]; then
                echo "错误: 找不到任何 my-skills-*.tar.gz" >&2
                exit 1
            fi
            echo "  找到: ${archive}"
            do_install "${archive}"
        else
            do_install "$2"
        fi
        ;;
    *)
        echo "用法:"
        echo "  $0 pack                 → 打包技能为 tar.gz"
        echo "  $0 install [archive]    → 解压 + 初始化 + 合并旧记忆"
        exit 1
        ;;
esac
