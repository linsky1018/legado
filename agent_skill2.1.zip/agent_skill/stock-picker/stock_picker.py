#!/usr/bin/env python3
"""
威科夫智能选股 - 使用 baostock 数据源
"""
import baostock as bs
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
from collections import Counter

# 行业关键词（匹配证监会行业分类）
HOT_KEYWORDS = [
    '电池','新能源','光伏','储能','半导体','芯片','电子',
    '有色','汽车','锂','能源','化工新材料','玻纤','计算机',
    '电气机械','仪器仪表','专用设备'
]

def login():
    lg = bs.login()
    if lg.error_code != '0':
        print(f'❌ 登录失败: {lg.error_msg}')
        return False
    return True

def get_hot_industries(top_n=5):
    """获取热门行业板块"""
    rs = bs.query_stock_industry()
    industries = []
    while rs.next():
        row = rs.get_row_data()
        if len(row) >= 5:
            industries.append({'code': row[1], 'industry': row[3], 'name': row[4]})

    ind_count = Counter(i['industry'] for i in industries)
    top = ind_count.most_common(30)

    hot = []
    for ind_name, count in top:
        if any(kw in ind_name for kw in HOT_KEYWORDS) and count >= 5:
            hot.append(ind_name)
        if len(hot) >= top_n:
            break

    if not hot:
        hot = [n for n, c in top[:top_n]]

    return hot, industries

def get_stock_codes(industries, hot_inds, max_per_ind=10):
    """获取热门行业中的个股代码"""
    codes = []
    for ind in hot_inds:
        ind_codes = [i for i in industries if i['industry'] == ind]
        for item in ind_codes[:max_per_ind]:
            codes.append((item['code'], ind))
    return codes

def get_kline(code, days=90):
    """获取K线数据"""
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')

    rs = bs.query_history_k_data_plus(code,
        "date,open,high,low,close,volume,amount,turn,pctChg",
        start_date=start_date, end_date=end_date,
        frequency="d", adjustflag="2")
    rows = []
    while rs.next():
        rows.append(rs.get_row_data())

    if len(rows) < 30:
        return pd.DataFrame()

    df = pd.DataFrame(rows, columns=['date','open','high','low','close','volume','amount','turn','pctChg'])
    for col in ['open','high','low','close','volume','amount','turn','pctChg']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    return df

def analyze_narrow_range(df, lookback=9):
    """
    窄幅震荡蓄势检测 (v6新增)
    检测突破前是否出现窄幅震荡蓄势形态
    返回 (bonus_score, details)
    """
    if len(df) < lookback + 2:
        return 0, {}

    pre = df.iloc[-(lookback+1):-1]  # 前N日（不含突破日）
    pct = pre['pctChg']

    # 1. 窄幅震荡指数 (NRI): 去掉最大波动日后的平均绝对涨跌
    max_idx = pct.abs().idxmax()
    without_max = pct.drop(max_idx)
    nri = without_max.abs().mean()

    if nri < 1.0:
        nri_score, nri_label = 15, f'NRI极度压缩({nri:.2f}%)'
    elif nri < 1.5:
        nri_score, nri_label = 12, f'NRI高度压缩({nri:.2f}%)'
    elif nri < 2.0:
        nri_score, nri_label = 8, f'NRI中度压缩({nri:.2f}%)'
    elif nri < 3.0:
        nri_score, nri_label = 5, f'NRI轻度压缩({nri:.2f}%)'
    else:
        nri_score, nri_label = 0, f'NRI未压缩({nri:.2f}%)'

    # 2. 小阴小阳占比
    small_count = (pct.abs() <= 3.0).sum()
    small_ratio = small_count / len(pct)

    if small_ratio >= 0.8:
        small_score, small_label = 12, f'小阴小阳{small_count}/{len(pct)}({small_ratio:.0%})'
    elif small_ratio >= 0.7:
        small_score, small_label = 10, f'小阴小阳{small_count}/{len(pct)}({small_ratio:.0%})'
    elif small_ratio >= 0.6:
        small_score, small_label = 7, f'小阴小阳{small_count}/{len(pct)}({small_ratio:.0%})'
    elif small_ratio >= 0.5:
        small_score, small_label = 4, f'小阴小阳{small_count}/{len(pct)}({small_ratio:.0%})'
    else:
        small_score, small_label = 0, f'小阴小阳{small_count}/{len(pct)}({small_ratio:.0%})'

    # 3. 连续小阴小阳天数
    consecutive = 0
    max_consecutive = 0
    for v in pct.values:
        if abs(v) <= 3.0:
            consecutive += 1
            max_consecutive = max(max_consecutive, consecutive)
        else:
            consecutive = 0

    if max_consecutive >= 5:
        consec_score, consec_label = 5, f'连续小阴小阳{max_consecutive}天'
    elif max_consecutive >= 4:
        consec_score, consec_label = 4, f'连续小阴小阳{max_consecutive}天'
    elif max_consecutive >= 3:
        consec_score, consec_label = 3, f'连续小阴小阳{max_consecutive}天'
    elif max_consecutive >= 2:
        consec_score, consec_label = 2, f'连续小阴小阳{max_consecutive}天'
    else:
        consec_score, consec_label = 0, f'连续小阴小阳{max_consecutive}天'

    # 4. 波动收窄 (前N日振幅 vs 前2N日振幅)
    if len(df) >= lookback * 2 + 2:
        pre_n = df.iloc[-(lookback+1):-1]
        pre_2n = df.iloc[-(lookback*2+1):-(lookback+1)]
        amp_n = ((pre_n['high'] - pre_n['low']) / pre_n['low']).mean() * 100
        amp_2n = ((pre_2n['high'] - pre_2n['low']) / pre_2n['low']).mean() * 100
        squeeze = amp_n / (amp_2n + 1e-10)

        if squeeze < 0.6:
            sqz_score, sqz_label = 8, f'波动收窄({squeeze:.2f})'
        elif squeeze < 0.8:
            sqz_score, sqz_label = 5, f'波动收窄({squeeze:.2f})'
        elif squeeze < 1.0:
            sqz_score, sqz_label = 2, f'波动收窄({squeeze:.2f})'
        else:
            sqz_score, sqz_label = 0, f'波动扩大({squeeze:.2f})'
    else:
        sqz_score, sqz_label = 0, '数据不足'
        squeeze = 1.0

    # 5. 缩量蓄势占比
    shrink_count = (pre['vol_ratio'] < 1.0).sum() if 'vol_ratio' in pre.columns else 0
    shrink_ratio = shrink_count / len(pre) if len(pre) > 0 else 0

    if shrink_ratio >= 0.5:
        vol_score, vol_label = 10, f'缩量{shrink_count}/{len(pre)}({shrink_ratio:.0%})'
    elif shrink_ratio >= 0.4:
        vol_score, vol_label = 8, f'缩量{shrink_count}/{len(pre)}({shrink_ratio:.0%})'
    elif shrink_ratio >= 0.3:
        vol_score, vol_label = 5, f'缩量{shrink_count}/{len(pre)}({shrink_ratio:.0%})'
    else:
        vol_score, vol_label = 0, f'缩量{shrink_count}/{len(pre)}({shrink_ratio:.0%})'

    total = nri_score + small_score + consec_score + sqz_score + vol_score

    details = {
        'nri': nri, 'nri_score': nri_score, 'nri_label': nri_label,
        'small_ratio': small_ratio, 'small_score': small_score, 'small_label': small_label,
        'max_consec': max_consecutive, 'consec_score': consec_score, 'consec_label': consec_label,
        'squeeze': squeeze, 'sqz_score': sqz_score, 'sqz_label': sqz_label,
        'shrink_ratio': shrink_ratio, 'vol_score': vol_score, 'vol_label': vol_label,
        'nr_total': total,
    }
    return total, details


def analyze(df):
    """技术分析，返回 (score, signals)"""
    # MA
    for p in [5, 10, 20]:
        df[f'MA{p}'] = df['close'].rolling(p).mean()

    # MACD
    ef = df['close'].ewm(span=12, adjust=False).mean()
    es = df['close'].ewm(span=26, adjust=False).mean()
    df['DIF'] = ef - es
    df['DEA'] = df['DIF'].ewm(span=9, adjust=False).mean()

    # KDJ
    ln = df['low'].rolling(9).min()
    hn = df['high'].rolling(9).max()
    rsv = (df['close'] - ln) / (hn - ln + 1e-10) * 100
    df['K'] = rsv.ewm(com=2, adjust=False).mean()
    df['D'] = df['K'].ewm(com=2, adjust=False).mean()

    # RSI
    dd = df['close'].diff()
    g6 = dd.where(dd > 0, 0).rolling(6).mean()
    l6 = (-dd.where(dd < 0, 0)).rolling(6).mean()
    df['RSI6'] = 100 - (100 / (1 + g6 / (l6 + 1e-10)))

    l = df.iloc[-1]
    pp = df.iloc[-2]

    sig = []
    score = 0

    # 均线多头排列 (+20)
    if l['MA5'] > l['MA10'] > l['MA20']:
        sig.append('均线多头')
        score += 20

    # MACD金叉 (+15~25)
    if pp['DIF'] <= pp['DEA'] and l['DIF'] > l['DEA']:
        if l['DIF'] > 0:
            sig.append('MACD零轴上金叉')
            score += 25
        else:
            sig.append('MACD金叉')
            score += 15
    elif l['DIF'] > l['DEA'] and l['DIF'] > 0:
        sig.append('MACD零轴上')
        score += 15

    # KDJ金叉 (+10~15)
    if pp['K'] <= pp['D'] and l['K'] > l['D'] and l['K'] < 80:
        sig.append('KDJ金叉')
        score += 15
    elif l['K'] > l['D'] and l['K'] < 60:
        sig.append('KDJ偏多')
        score += 10

    # 成交量（移除放量加分，该指标为反向信号）
    # avg_v = df['volume'].iloc[-6:-1].mean()
    # if df['volume'].iloc[-1] > avg_v * 1.3:
    #     sig.append('放量')
    #     score += 15

    # 涨幅适中 (+10)
    pct = l.get('pctChg', 0)
    if not pd.isna(pct) and 1 <= pct <= 7:
        sig.append('涨幅适中')
        score += 10

    # 换手率活跃 (+5)
    turn = l.get('turn', 0)
    if not pd.isna(turn) and turn > 1:
        sig.append('换手活跃')
        score += 5

    # RSI健康 (+5)
    if 30 < l['RSI6'] < 70:
        sig.append('RSI健康')
        score += 5

    # 窄幅震荡蓄势 (v6) — 需均线支撑才全额给分
    nr_bonus, nr_details = analyze_narrow_range(df)
    if nr_bonus > 0:
        # 均线调制：均线好才给窄幅蓄势全额分
        ma_ok = l['MA5'] > l['MA10']  # 至少短期均线多头
        ma_strong = l['MA5'] > l['MA10'] > l['MA20']  # 全部多头

        if ma_strong:
            ma_factor = 1.0   # 全额
        elif ma_ok:
            ma_factor = 0.6   # 打6折
        else:
            ma_factor = 0.3   # 打3折（均线差，窄幅可能是阴跌不是蓄势）

        nr_adjusted = int(nr_bonus * ma_factor)
        if nr_adjusted > 0:
            score += nr_adjusted
            tag = '' if ma_factor == 1.0 else f'(×{ma_factor})'
            sig.append(nr_details['nri_label'] + tag)
            if nr_details['max_consec'] >= 3:
                sig.append(nr_details['consec_label'])

    return score, sig, l

def main():
    print('🔍 威科夫智能选股...')
    print(f'⏰ {datetime.now().strftime("%Y-%m-%d %H:%M")}')
    print(f'📡 数据源: baostock\n')

    if not login():
        return

    # 1. 行业板块
    print('[1/4] 获取行业板块...')
    hot_inds, industries = get_hot_industries()
    print(f'  关注行业: {[n[:12] for n in hot_inds]}')

    # 2. 筛选个股
    print('\n[2/4] 筛选候选股...')
    stock_list = get_stock_codes(industries, hot_inds)
    print(f'  共 {len(stock_list)} 只候选')

    # 3. 获取K线
    print('\n[3/4] 获取K线数据...')
    stock_data = {}
    for code, ind in stock_list[:30]:
        df = get_kline(code)
        if not df.empty:
            stock_data[code] = {'df': df, 'ind': ind}
        time.sleep(0.3)
    print(f'  获取到 {len(stock_data)} 只有效数据')

    # 4. 技术分析
    print('\n[4/4] 技术分析...\n')
    results = []

    for code, info in stock_data.items():
        df = info['df'].copy()
        # 计算量比（供窄幅震荡检测使用）
        df['vol_avg5'] = df['volume'].rolling(5).mean()
        df['vol_ratio'] = df['volume'] / (df['vol_avg5'] + 1e-10)

        score, sig, latest = analyze(df)

        pct = latest.get('pctChg', 0)
        if pd.isna(pct):
            pct = 0

        if score >= 70:
            results.append({
                'code': code,
                'name': code,
                'pct': pct,
                'ind': info['ind'],
                'score': score,
                'sig': sig,
                'close': latest['close'],
                'turn': latest.get('turn', 0),
                'vol': latest['volume'],
            })

    results.sort(key=lambda x: x['score'], reverse=True)

    # 查询股票名称
    for r in results[:8]:
        rs = bs.query_stock_basic(code=r['code'])
        if rs.next():
            row = rs.get_row_data()
            r['name'] = row[1] if len(row) > 1 else r['code']
        else:
            r['name'] = r['code']
        time.sleep(0.1)

    # 输出
    print('=' * 50)
    print(f'# 选股结果 {datetime.now().strftime("%Y-%m-%d %H:%M")}')
    print(f'方法：威科夫选股法 | 候选：{len(results)} 只')
    print(f'关注行业：{", ".join(n[:10] for n in hot_inds[:5])}\n')

    if not results:
        print('⚠️ 今日暂无符合条件的个股')
        # 展示涨幅前5
        all_stocks = []
        for code, info in stock_data.items():
            df = info['df']
            pct = df['pctChg'].iloc[-1] if not pd.isna(df['pctChg'].iloc[-1]) else 0
            all_stocks.append((code, info['name'], info['ind'], pct))
        all_stocks.sort(key=lambda x: x[3], reverse=True)
        if all_stocks:
            print('\n今日涨幅前5（仅供参考）:')
            for code, name, ind, pct in all_stocks[:5]:
                print(f'  {name} ({code}) | {ind[:12]} | {pct:+.2f}%')
    else:
        medals = ['🥇', '🥈', '🥉']
        for i, r in enumerate(results[:8]):
            star = '⭐' if r['score'] >= 90 else '✅' if r['score'] >= 70 else '🟡'
            m = medals[i] if i < 3 else f'{"④⑤⑥⑦⑧"[i-3]}'
            turn_str = f'{r["turn"]:.1f}%' if r['turn'] and not pd.isna(r['turn']) else 'N/A'
            print(f'{m} {r["name"]} ({r["code"]}) {star}')
            print(f'  行业：{r["ind"][:15]} | 涨幅：{r["pct"]:+.2f}% | 收盘：{r["close"]:.2f}')
            print(f'  换手：{turn_str} | 信号：{" / ".join(r["sig"])}')
            print(f'  综合评分：{r["score"]}/100\n')

    print('⚠️ 技术面分析不构成投资建议，股市有风险，投资需谨慎')
    bs.logout()

if __name__ == '__main__':
    main()
