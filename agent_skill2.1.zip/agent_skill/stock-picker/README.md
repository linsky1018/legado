# 2026-04-10

## stock-picker skill 安装

从 https://getnote.top/gupiao1~gupiao6 下载了 6 个选股相关文件，安装为 OpenClaw skill。

### 文件结构
```
~/.openclaw/skills/stock-picker/
~/.openclaw/workspace/stock-picker/
```
两个目录内容完全一致。

### 文件命名规范
- `SKILL.md` — OpenClaw 固定命名，不可改
- `stock_picker.py` — Python 脚本，下划线惯例
- 其他文件统一 `stock-picker-` 前缀（如 stock-picker-reference.md）
- examples/ 下用 `result_YYYY-MM-DD.md` 命名

### 同步规则
**每次 stock-picker skill 有更新，skills/ 和 workspace/ 两个目录必须同步。**

### Python 依赖安装

```bash
pip install baostock pandas numpy --break-system-packages
```

| 包名 | 用途 |
|------|------|
| baostock | A股K线数据源（免费） |
| pandas | 数据处理与分析 |
| numpy | 数值计算 |

如系统限制 PEP 668，加 `--break-system-packages` 参数。
