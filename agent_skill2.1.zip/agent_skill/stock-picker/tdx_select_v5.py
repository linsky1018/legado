"""
策略5（单文件版）— 无外部依赖，直接运行

★ 命名规则：变量名直接反映含义，不缩写
★ 6层短路逻辑：A.基本动量 → B.K线形态 → C.趋势确认 → D.量能 → E.波动 → F.支撑

依赖：numpy（pip install numpy）
"""

import numpy as np
import pickle
import os
import sys


#================================================================================
# 内联工具函数（原 tdx_utils.py）
#================================================================================
def shift(arr, n):
    """数组位移，前n位填nan"""
    r = np.empty_like(arr)
    r[:n] = np.nan
    r[n:] = arr[:-n]
    return r


def rmax2(arr):
    """滚动2日最大值"""
    s = shift(arr, 1)
    return np.fmax(arr, np.where(np.isnan(s), arr, s))


def rmax3(arr):
    """滚动3日最大值"""
    s1 = shift(arr, 1)
    s2 = shift(arr, 2)
    a = np.fmax(arr, np.where(np.isnan(s1), arr, s1))
    return np.fmax(a, np.where(np.isnan(s2), arr, s2))


def rmin2(arr):
    """滚动2日最小值"""
    s = shift(arr, 1)
    return np.fmin(arr, np.where(np.isnan(s), arr, s))


def rmin3(arr):
    """滚动3日最小值"""
    s1 = shift(arr, 1)
    s2 = shift(arr, 2)
    a = np.fmin(arr, np.where(np.isnan(s1), arr, s1))
    return np.fmin(a, np.where(np.isnan(s2), arr, s2))


def rsum3(arr):
    """滚动3日求和"""
    return arr + np.nan_to_num(shift(arr, 1)) + np.nan_to_num(shift(arr, 2))


def ema(arr, span):
    """
    指数移动平均（纯 numpy 实现，等价于 pandas ewm(alpha=2/(span+1), adjust=False)）
    """
    alpha = 2.0 / (span + 1)
    out = np.empty(len(arr), dtype=np.float64)
    if len(arr) == 0:
        return out
    out[0] = float(arr[0]) if not np.isnan(arr[0]) else np.nan
    for i in range(1, len(arr)):
        v = float(arr[i])
        if np.isnan(v):
            out[i] = out[i - 1]
        elif np.isnan(out[i - 1]):
            out[i] = v
        else:
            out[i] = alpha * v + (1 - alpha) * out[i - 1]
    return out


def find_date_index(data, target_date):
    """二分查找最后一个 date <= target_date 的索引"""
    dates = data['date']
    idx = int(np.searchsorted(dates, target_date, side='right')) - 1
    return idx if idx >= 0 else -1


#================================================================================
# 内联 quick_filter（原 tdx_select.py）
#================================================================================
def quick_filter(data, target_idx=None, quote=None):
    """
    快速过滤，返回 True 表示可能符合，False 表示直接排除
    """
    if target_idx is None:
        target_idx = len(data) - 1
    if target_idx < 30:
        return False

    C = data['C']
    C1 = C[target_idx - 1]
    H = data['H']
    L = data['L']

    # 1. 涨幅必须大于3.5%
    if quote is not None and quote.last_price > 0:
        C_now = quote.last_price
    else:
        C_now = C[target_idx]
    if C_now <= C1 * 1.035:
        return False

    # 2. 收盘价必须高于前3日最高收盘价
    if target_idx < 3:
        return False
    HC3 = max(C[target_idx - 1], C[target_idx - 2], C[target_idx - 3])
    if C_now <= HC3:
        return False

    # 3. 当日必须有波动（不是一字板）
    if quote is not None and quote.high_price > 0 and quote.low_price > 0:
        if quote.high_price <= quote.low_price:
            return False
    else:
        if H[target_idx] <= L[target_idx]:
            return False

    # 4. 收盘价必须高于5日均价
    if target_idx < 5:
        return False
    MA5 = np.mean(C[target_idx - 4:target_idx + 1])
    if C_now <= MA5:
        return False

    return True


#================================================================================
# 参数（硬编码，无需 config.yaml）
#================================================================================
BAD_BLOCK_WORDS = [
    '高股息','猪肉','鸡肉','行业龙头','人脑工程',
    '银行','保险','证券','白酒','煤炭','石油',
    '房地产','基建','钢铁','电力','高速公路',
]
ATR_MIN_PCT = 0.3
AMOUNT_MAX_YI = 50.0
CHG_MIN_PCT = 3.5


#================================================================================
# 高级过滤
#================================================================================
def v5_advanced_filter(data, idx, close, amount, name='', blocks=None):
    """ST / 成交额上限 / 板块黑名单 / ATR"""
    if name and ('ST' in name or '*ST' in name): 
        return False
    if amount > AMOUNT_MAX_YI * 1e8: 
        return False
    C = data['C']
    if idx < 1 or C[idx-1] <= 0: 
        return False
    if (close / C[idx-1] - 1) * 100 < CHG_MIN_PCT: 
        return False
    if blocks:
        block_text = ' '.join(
            b.get('block_name','') if isinstance(b,dict) else b for b in blocks)
        if any(kw in block_text for kw in BAD_BLOCK_WORDS):
            return False
    if idx >= 14:
        H, L = data['H'], data['L']
        tr = np.maximum(H[idx-13:idx+1] - L[idx-13:idx+1],
                 np.maximum(np.abs(H[idx-13:idx+1] - C[idx-14:idx]),
                            np.abs(L[idx-13:idx+1] - C[idx-14:])))
        if np.mean(tr) / close * 100 < ATR_MIN_PCT:
            return False
    return True


#================================================================================
# 主选股（v5，单文件版）
#================================================================================
def select_stock_v5(data, target_idx=None, use_advanced_filter=False, quote=None):
    """
    v5 主策略 — 分层短路，变量名语义化
    
    返回: (是否通过, 收盘价, 成交额)
    """
    # ---- 前置检查 ----
    if target_idx is None:
        target_idx = len(data) - 1
    if target_idx < 30:
        return False, 0.0, 0.0

    if quote is not None and quote.last_price > 0:
        close = float(quote.last_price)
    else:
        close = float(data['C'][target_idx])
    amount = float(data['A'][target_idx])

    # 第0层：quick_filter 预筛
    if not quick_filter(data, target_idx, quote=quote):
        return False, close, amount

    if use_advanced_filter:
        if not v5_advanced_filter(data, target_idx, close, amount):
            return False, close, amount

    # ---- 截取数据到当日 ----
    O = data['O'][:target_idx + 1]
    C = data['C'][:target_idx + 1]
    H = data['H'][:target_idx + 1]
    L = data['L'][:target_idx + 1]
    A = data['A'][:target_idx + 1]

    last = -1

    # =========================================================================
    # 第1步：numpy 向量化计算全部中间变量
    # =========================================================================

    # --- 历史价格引用 ---
    prev_close = shift(C, 1)
    close_2d = shift(C, 2)
    close_3d = shift(C, 3)
    close_4d = shift(C, 4)
    open_1d = shift(O, 1)
    open_2d = shift(O, 2)
    open_3d = shift(O, 3)
    open_4d = shift(O, 4)
    high_1d = shift(H, 1)
    high_2d = shift(H, 2)
    low_1d = shift(L, 1)

    # --- 实体与振幅 ---
    body_high = np.fmax(prev_close, open_1d)
    body_low = np.fmin(prev_close, open_1d)
    body_high_2d = np.fmax(close_2d, open_2d)

    nan = np.nan
    body_low_safe = np.where(body_low == 0, nan, body_low)

    chg_today_arr = C / np.where(prev_close == 0, nan, prev_close)
    day_range = body_high / body_low_safe

    range_3d = rmax3(body_high) / np.where(rmin3(body_high)==0, nan, rmin3(body_high))
    range_2d = rmax2(body_high) / np.where(rmin2(body_high)==0, nan, rmin2(body_high))
    range_3d_prev = np.where(np.isnan(shift(range_3d, 1)), 999.0, shift(range_3d, 1))

    high_close_3d = rmax3(prev_close)

    # --- 3日持续性 ---
    body_high_prev2 = shift(body_high, 2)
    body_high_prev1 = shift(body_high, 1)
    bh_prev2_safe = np.where(body_high_prev2==0, nan, body_high_prev2)
    persist_3d = (
        ((body_high/bh_prev2_safe >= 0.985) & (body_high/bh_prev2_safe <= 1.013)) |
        ((body_high_prev1/bh_prev2_safe >= 0.985) & (body_high_prev1/bh_prev2_safe <= 1.013))
    )

    # --- 动态阈值系统 ---
    low_max3 = rmax3(low_1d); low_min3 = rmin3(low_1d)
    low_min3_safe = np.where(low_min3==0, nan, low_min3)
    volatile_coef = np.where(
        (range_3d < 1.0172) |
        ((low_max3 / low_min3_safe < 1.011) & (L[last]*1.01 > prev_close[last])),
        1.0235, 1.0
    )
    volatile_prev = np.where(np.isnan(shift(volatile_coef,1)), 1.0, shift(volatile_coef,1))
    persist_coef = np.where(
        (range_3d < 1.03) | (range_3d_prev < 1.016),
        1.018 * volatile_coef * volatile_prev,
        1.0165
    )

    jump_up = (O*1.003 > prev_close) & (chg_today_arr > 1.05)

    narrow_days = rsum3((day_range < 1.021).astype(np.float64))
    tight_days  = rsum3((day_range < 1.013).astype(np.float64))

    # --- ZXST/ZXZF 趋势/涨幅系数 ---
    trend_coef = np.where(
        ((narrow_days > 1) | jump_up) &
        ((range_3d < 1.013) | (range_3d_prev < 1.013) | (tight_days > 1)),
        1.013, 1.0
    )
    chg_coef = np.where(
        (narrow_days > 0) & ((range_3d < 1.015) | (range_3d_prev < 0.007)),
        0.993, 1.0
    )
    boost_coef = np.where(
        (range_2d < 1.0125) | (range_3d_prev < 1.01) | persist_3d,
        1.0235, 1.0
    )
    boost3_coef = np.where(
        (tight_days > 1) & (range_2d < 1.0125) & persist_3d,
        1.018, 1.0
    )

    break_thresh = np.minimum(1.021 * persist_coef * boost_coef, 1.039)
    break_thresh2 = np.minimum(1.0259 * persist_coef * boost3_coef, 1.034)
    below_thresh_count = rsum3((day_range < break_thresh).astype(np.float64))

    # --- EMA均线与量能 ---
    ema7 = ema(C, 7)
    ema15 = ema(C, 15)
    ma_amount_5d = (A + np.nan_to_num(shift(A,1)) + np.nan_to_num(shift(A,2)) +
                    np.nan_to_num(shift(A,3)) + np.nan_to_num(shift(A,4))) / 5
    vol_surge = A > ma_amount_5d * 0.45
    amount_yi = A / 1e8

    # --- 开盘位置相关系数 ---
    gap_coef = np.where((O > prev_close) & (prev_close > close_2d), 1.005, 1.0)
    aggressive_coef = np.where(
        ((O*1.007 > body_low) & (chg_today_arr > 1.051)) | (range_3d < 1.011) | (tight_days > 1),
        1.0245, 1.003
    )
    extreme_coef = np.where(
        ((O*1.012 > body_low) & (chg_today_arr > 1.051)) | (range_3d < 1.011),
        1.1008, 1.0
    )
    high_3d_body = rmax3(body_high)
    near_high_coef = np.where(
        (high_3d_body / np.where(O==0, nan, O) >= 0.995) &
        (high_3d_body / np.where(O==0, nan, O) <= 1.005),
        1.015, 1.0
    )

    # --- 安全除零保护 ---
    body_high_safe = np.where(body_high == 0, nan, body_high)
    body_high_2d_safe = np.where(body_high_2d == 0, nan, body_high_2d)
    close_2d_safe = np.where(close_2d == 0, nan, close_2d)
    open_safe = np.where(O == 0, nan, O)

    # =========================================================================
    # 第2步：提取当日所有标量值
    # =========================================================================
    c   = float(C[last])
    o   = float(O[last])
    h1  = float(high_1d[last])
    l1  = float(low_1d[last])
    h2  = float(high_2d[last])

    c1  = float(prev_close[last])
    c2  = float(close_2d[last])
    c4  = float(close_4d[last])
    o1  = float(open_1d[last])
    o2  = float(open_2d[last])
    o3  = float(open_3d[last])
    o4  = float(open_4d[last])

    chg_pct    = float(chg_today_arr[last])
    day_rng    = float(day_range[last])
    narrow_cnt = float(below_thresh_count[last])
    hc3        = float(high_close_3d[last])

    e7         = float(ema7[last])
    e15        = float(ema15[last])
    is_vol_up  = bool(vol_surge[last])
    amt_yi     = float(amount_yi[last])

    r3d        = float(range_3d[last])
    r2d        = float(range_2d[last])
    r3d_prev   = float(range_3d_prev[last])
    vol_co     = float(volatile_coef[last])
    per_co     = float(persist_coef[last])

    trnd_co    = float(trend_coef[last])
    chg_co     = float(chg_coef[last])
    bst_co     = float(boost_coef[last])
    bst3_co    = float(boost3_coef[last])
    gap_co     = float(gap_coef[last])
    agg_co     = float(aggressive_coef[last])
    ext_co     = float(extreme_coef[last])
    near_co    = float(near_high_coef[last])

    is_jump    = bool(jump_up[last])
    tight_cnt  = float(tight_days[last])
    is_persist = bool(persist_3d[last])

    p1_hi_val  = float(body_high_safe[last])
    p2_hi_val  = float(body_high_2d_safe[last])
    c2_safe    = float(close_2d_safe[last])
    o_safe     = float(open_safe[last])
    hi3_val    = float(high_3d_body[last])

    brk2_val   = float(break_thresh2[last])

    # =========================================================================
    # 第3步：逐层短路判断
    # =========================================================================

    # === A层：基本动量要求 ===
    if chg_pct <= 1.0413 * chg_co:
        return False, close, amount
    if narrow_cnt <= 1:
        return False, close, amount

    # === B层：K线形态要求 ===
    if h1 <= l1:
        return False, close, amount
    if not (o2 / c1 < 1.049 or is_jump):
        return False, close, amount
    if c <= hc3:
        return False, close, amount
    if o1 / c2_safe >= 1.059:
        return False, close, amount
    if c2 / p1_hi_val >= 1.029:
        return False, close, amount

    # === C层：趋势确认（EMA）===
    if e7 * trnd_co <= e15:
        return False, close, amount
    if c <= e7 * gap_co * bst_co:
        return False, close, amount
    if hi3_val * 1.011 * trnd_co <= e15:
        return False, close, amount
    if c / e15 <= 1.01:
        return False, close, amount

    # === D层：量能与涨幅 ===
    if not (is_vol_up or chg_pct > 1.055 or amt_yi > 1.25):
        return False, close, amount

    # === E层：涨幅与波动约束 ===
    if not (day_rng < brk2_val or c1 / c2_safe < 1.03 * trnd_co):
        return False, close, amount
    if not (r2d < 1.0236 * per_co or is_persist or tight_cnt > 1):
        return False, close, amount

    # === F层：回撤与支撑约束 ===
    if h2 * 0.97 / p1_hi_val >= 1.039 * bst_co * vol_co:
        return False, close, amount
    if not (c1 / p2_hi_val < 1.0297 * bst_co or tight_cnt > 1):
        return False, close, amount
    if o4 / c2_safe >= 1.026 * bst_co * bst3_co * near_co * trnd_co:
        return False, close, amount
    if not (o3 / c2_safe < 1.039 * ext_co or c4 / c2_safe < 1.039 * agg_co):
        return False, close, amount
    if not (o1 / o_safe < 1.0315 * ext_co or day_rng < 1.013):
        return False, close, amount

    return True, c, amount


#================================================================================
# 未来涨幅统计工具
#================================================================================
def calc_future_max_gain(data, sel_idx, lookahead_days=3):
    """
    计算选股后(含当日)lookahead_days天内相对选股前一日收盘的最高涨幅%
    
    Args:
        data: numpy array with fields 'C'
        sel_idx: 选股日索引
        lookahead_days: 向前看的天数（默认3天）
    
    Returns:
        float: 最高涨幅百分比，如 5.23 表示涨5.23%
    """
    if sel_idx < 1:
        return None
    C_base = data['C'][sel_idx - 1]
    if C_base <= 0:
        return None
    data_len = len(data)
    end_idx = min(sel_idx + lookahead_days, data_len - 1)
    C_future = data['C'][sel_idx:end_idx + 1]
    C_future_valid = C_future[C_future > 0]
    if len(C_future_valid) == 0:
        return None
    return round(float((np.max(C_future_valid) / C_base - 1) * 100), 2)


def calc_future_return(data, sel_idx, hold_days=3):
    """
    计算选股后持有hold_days天的收益率（收盘价计算）
    
    Args:
        data: numpy array with fields 'C'
        sel_idx: 选股日索引
        hold_days: 持有天数（默认3天）
    
    Returns:
        float: 收益率百分比，如 -2.5 表示亏2.5%
    """
    if sel_idx < 1 or sel_idx + hold_days >= len(data):
        return None
    buy_price = data['C'][sel_idx]
    sell_price = data['C'][sel_idx + hold_days]
    if buy_price <= 0:
        return None
    return round(float((sell_price / buy_price - 1) * 100), 2)


#================================================================================
# 测试方法：从缓存文件读取数据并调用v5选股
#================================================================================
def test_v5_from_cache(cache_path=None, date_str=None, use_advanced_filter=False, 
                       lookahead_days=3, analyze_future=False):
    """
    从缓存文件读取数据，调用v5方法进行选股测试
    
    Args:
        cache_path: 缓存文件路径，None则使用默认路径
        date_str: 目标日期(格式: YYYY-MM-DD 或 YYYYMMDD)，None则使用最新日期
        use_advanced_filter: 是否使用高级过滤
        lookahead_days: 向前看的天数（用于未来涨幅统计）
        analyze_future: 是否统计选中后的未来涨幅
    
    Returns:
        list: [(code, close, amount, max_gain, hold_return), ...] 选中的股票列表
    """
    # 默认缓存路径
    if cache_path is None:
        # 尝试从环境变量或常见位置找
        cache_path = r"D:\Open\TdxTq\vipdoc\tdx_market_cache.pkl"
        if not os.path.exists(cache_path):
            # 尝试当前目录
            cache_path = "tdx_market_cache.pkl"
    
    print(f"[缓存] 加载: {cache_path}")
    with open(cache_path, 'rb') as f:
        cache = pickle.load(f)
    
    # 缓存结构: {'stocks': {...}, 'code_to_market': {...}}
    stocks = cache.get('stocks', cache) if isinstance(cache, dict) else cache
    print(f"[缓存] 股票数量: {len(stocks)}")
    
    # 处理日期
    if date_str is None:
        sample_code = list(stocks.keys())[0]
        sample_data = stocks[sample_code]
        target_date_int = int(sample_data['date'][-1])
        date_str = str(target_date_int)
    else:
        date_str = date_str.replace('-', '')
        target_date_int = int(date_str)
    
    print(f"[日期] 目标: {date_str}")
    print(f"[统计] 未来{lookahead_days}日涨幅分析: {'开启' if analyze_future else '关闭'}")
    
    results = []
    
    for code, data in stocks.items():
        idx = find_date_index(data, target_date_int)
        if idx < 0:
            continue
        
        passed, close, amount = select_stock_v5(data, target_idx=idx, use_advanced_filter=use_advanced_filter)
        if passed:
            max_gain = None
            hold_return = None
            if analyze_future:
                max_gain = calc_future_max_gain(data, idx, lookahead_days)
                hold_return = calc_future_return(data, idx, lookahead_days)
            results.append((code, close, amount, max_gain, hold_return))
    
    # 按成交额降序排序
    results.sort(key=lambda x: x[2], reverse=True)
    
    print(f"\n[V5] 选股完成: 共选中 {len(results)} 只")
    
    # 打印结果
    if analyze_future:
        # 按最高涨幅降序排列
        results_by_gain = sorted(results, key=lambda x: x[3] if x[3] is not None else -999, reverse=True)
        
        print(f"\n前20只（按成交额降序）:")
        print(f"{'序号':<6}{'代码':<10}{'价格':<10}{'成交额(亿)':<12}{'最高涨幅%':<12}{'持有收益%':<12}")
        print("-" * 65)
        for i, (code, close, amount, max_gain, hold_return) in enumerate(results[:20], 1):
            amt_yi = amount / 1e8
            gain_str = f"{max_gain:.2f}" if max_gain is not None else "N/A"
            ret_str = f"{hold_return:.2f}" if hold_return is not None else "N/A"
            print(f"{i:<6}{code:<10}{close:<10.2f}{amt_yi:<12.2f}{gain_str:<12}{ret_str:<12}")
        
        print(f"\n前20只（按最高涨幅%降序）:")
        print(f"{'序号':<6}{'代码':<10}{'价格':<10}{'成交额(亿)':<12}{'最高涨幅%':<12}{'持有收益%':<12}")
        print("-" * 65)
        for i, (code, close, amount, max_gain, hold_return) in enumerate(results_by_gain[:20], 1):
            amt_yi = amount / 1e8
            gain_str = f"{max_gain:.2f}" if max_gain is not None else "N/A"
            ret_str = f"{hold_return:.2f}" if hold_return is not None else "N/A"
            print(f"{i:<6}{code:<10}{close:<10.2f}{amt_yi:<12.2f}{gain_str:<12}{ret_str:<12}")
        
        # 统计汇总
        valid_gains = [r[3] for r in results if r[3] is not None]
        valid_returns = [r[4] for r in results if r[4] is not None]
        
        if valid_gains:
            print(f"\n[统计] 未来{lookahead_days}日最高涨幅:")
            print(f"  平均: {np.mean(valid_gains):.2f}%")
            print(f"  中位数: {np.median(valid_gains):.2f}%")
            print(f"  最大: {np.max(valid_gains):.2f}%")
            print(f"  最小: {np.min(valid_gains):.2f}%")
            print(f"  >=5%胜率: {sum(1 for g in valid_gains if g >= 5) / len(valid_gains) * 100:.1f}%")
            print(f"  >=10%胜率: {sum(1 for g in valid_gains if g >= 10) / len(valid_gains) * 100:.1f}%")
        
        if valid_returns:
            print(f"\n[统计] 未来{lookahead_days}日持有收益:")
            print(f"  平均: {np.mean(valid_returns):.2f}%")
            print(f"  中位数: {np.median(valid_returns):.2f}%")
            print(f"  正收益胜率: {sum(1 for r in valid_returns if r > 0) / len(valid_returns) * 100:.1f}%")
    else:
        print(f"\n前20只:")
        print(f"{'序号':<6}{'代码':<10}{'价格':<10}{'成交额(亿)':<12}")
        print("-" * 40)
        for i, (code, close, amount, _, _) in enumerate(results[:20], 1):
            amt_yi = amount / 1e8
            print(f"{i:<6}{code:<10}{close:<10.2f}{amt_yi:<12.2f}")
    
    return results


if __name__ == "__main__":
    # 命令行测试: python tdx_select_v5.py [日期] [缓存路径] [--analyze] [--days N]
    date_arg = None
    cache_arg = None
    analyze_arg = False
    days_arg = 3
    
    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == '--analyze' or arg == '-a':
            analyze_arg = True
            i += 1
        elif arg == '--days' or arg == '-d':
            if i + 1 < len(sys.argv):
                days_arg = int(sys.argv[i + 1])
                i += 2
            else:
                i += 1
        elif arg.startswith('-'):
            i += 1
        elif date_arg is None:
            date_arg = arg
            i += 1
        elif cache_arg is None:
            cache_arg = arg
            i += 1
        else:
            i += 1
    
    test_v5_from_cache(cache_path=cache_arg, date_str=date_arg, 
                       use_advanced_filter=False, 
                       lookahead_days=days_arg, 
                       analyze_future=analyze_arg)
