# Hermes Workspace State

## Seeded Files
- AGENTS.md: Added Hermes retrieval block in Session Startup; refined memory routing bullets
- SOUL.md: Added Hermes Pressure block
- HEARTBEAT.md: Added Hermes Maintenance checklist

## Constraints

