# Hermes Agent Memory

## Status
status: active
version: 1.0.0
last: 2026-04-17
integration: active

## Workspace Snapshot
- AGENTS.md: patched with Hermes retrieval block
- SOUL.md: patched with Hermes pressure block
- HEARTBEAT.md: patched with Hermes maintenance tasks

## Active Rules
- stock-picker 模型优化必须匹配实际持股周期：超短(2-3天)和中线(10天)特征完全相反
- 回测验证要用止盈模式（首次触达目标价卖出），比固定天数更贴近实战
- 共识筛选思路：取TOP赢者共同特征作为正因子，排除非共识的噪音股票
- 模型文件命名：v5=基础策略，v7/v8=中线，v9=超短

## Promotion Signals
- v9_sprint.py 超短筛选器 → 3次实测/回测验证通过，可作为稳定工具

## Notes
- Initialized on 2026-04-17 from hermes-agent skill
- 今日完成：my-skills 打包脚本、hermes-agent 初始化、v5→v9 模型四轮迭代优化

---
Updated: 2026-04-17
